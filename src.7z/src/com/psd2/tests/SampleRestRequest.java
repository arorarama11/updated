package com.psd2.tests;


public class SampleRestRequest{
	
	SampleRestRequest(){
		System.out.println("I am in const");
	}
	public static void test(){
		System.out.println("I am in test");
	}
	
	public static void main(String args[]) {
		
		String str = null;
		System.out.println(str==null);
}
		
		
}
