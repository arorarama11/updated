package com.psd2.tests.pisp.GET_DomesticPaymentConsents;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.psd2.core.TestBase;
import com.psd2.logger.TestListener;
import com.psd2.logger.TestLogger;

/**
 * Class Description : Verification of the values into OPTIONAL  SCASupportData optional block where Request has sent successfully and returned a HTTP Code 200 OK 
 * @author : Kiran Dewangan
 *
 */

@Listeners( { TestListener.class })
@Test(groups={"Regression"})
public class PISP_GDPC_091 extends TestBase{	
	
	@Test
	public void m_PISP_GDPC_091() throws Throwable{	
		
		TestLogger.logStep("[Step 1] : Creating client credetials....");
        createClientCred.setBaseURL(apiConst.cc_endpoint);
        createClientCred.setScope("payments");
        createClientCred.submit();
        testVP.assertStringEquals(String.valueOf(createClientCred.getResponseStatusCode()),"200",
                                     "Response Code is correct for client credetials");
        cc_token = createClientCred.getAccessToken();
        TestLogger.logVariable("AccessToken : " + cc_token);    
        TestLogger.logBlankLine();
        
        TestLogger.logStep("[Step 2] : Verification of response for the consent API");                          
        paymentConsent.setBaseURL(apiConst.dpc_endpoint);
        paymentConsent.setHeadersString("Authorization:Bearer "+cc_token);
        paymentConsent.submit();
        
		String consentId=paymentConsent.getConsentId();
		
		TestLogger.logStep("[Step 3] : GET Domestic Payments");	
		paymentConsent.setBaseURL(apiConst.dpc_endpoint+"/"+consentId);
		paymentConsent.setHeadersString("Authorization:Bearer "+cc_token);
		paymentConsent.setMethod("GET");
		paymentConsent.submit();
				
		testVP.assertStringEquals(String.valueOf(paymentConsent.getResponseStatusCode()),"200", 
				"Response Code is correct for GET Domestic Payment Consents");
		testVP.assertTrue((paymentConsent.getResponseValueByPath("Data.SCASupportData"))!=null, 
				"Mandatory Block SCASupportData is present"+paymentConsent.getResponseValueByPath("Data.SCASupportData"));			
		testVP.assertTrue((paymentConsent.getResponseValueByPath("Data.SCASupportData.RequestedSCAExemptionType"))!=null, 
				"Optional field RequestedSCAExemptionType is present in SCASupportData block "+ paymentConsent.getResponseValueByPath("Data.SCASupportData.RequestedSCAExemptionType"));
		testVP.assertTrue((paymentConsent.getResponseValueByPath("Data.SCASupportData.AppliedAuthenticationApproach"))!=null, 
				"Optional field appliedAuthenticationApproach is present in SCASupportData block "+paymentConsent.getResponseValueByPath("Data.SCASupportData.AppliedAuthenticationApproach"));
		testVP.assertTrue((paymentConsent.getResponseValueByPath("Data.SCASupportData.ReferencePaymentOrderId"))!=null, 
				"Optional field referencePaymentOrderId is present in SCASupportData block "+paymentConsent.getResponseValueByPath("Data.SCASupportData.ReferencePaymentOrderId"));
		TestLogger.logBlankLine();
		testVP.testResultFinalize();
	}
}

