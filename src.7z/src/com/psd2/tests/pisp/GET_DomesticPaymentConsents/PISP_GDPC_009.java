package com.psd2.tests.pisp.GET_DomesticPaymentConsents;

import com.psd2.core.TestBase;

public class PISP_GDPC_009 extends TestBase{
	
	
}