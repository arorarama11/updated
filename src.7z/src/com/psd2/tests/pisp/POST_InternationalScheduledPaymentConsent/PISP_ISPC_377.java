package com.psd2.tests.pisp.POST_InternationalScheduledPaymentConsent;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.psd2.core.TestBase;
import com.psd2.logger.TestListener;
import com.psd2.logger.TestLogger;

/**
 * Class Description : Verification of Permission 
 * @author : Rama Arora
 *
 */

@Listeners( { TestListener.class })
@Test(groups={"Regression"})
public class PISP_ISPC_377 extends TestBase{	
	
	@Test
	public void m_PISP_ISPC_377() throws Throwable{	
		
		 TestLogger.logStep("[Step 1-1] : Creating client credetials....");
			
			createClientCred.setBaseURL(apiConst.cc_endpoint);
			createClientCred.setScope("payments");
			createClientCred.submit();
			
			testVP.assertStringEquals(String.valueOf(createClientCred.getResponseStatusCode()),"200",
					"Response Code is correct for client credetials");
			cc_token = createClientCred.getAccessToken();
			TestLogger.logVariable("AccessToken : " + cc_token);
				
			TestLogger.logBlankLine();
			
			TestLogger.logStep("[Step 1-2] :Verification of Permission while Post International Scheduled Payment Consents SetUp");
			
			iScheduledPayment.setBaseURL(apiConst.iScheduledPaymentConsent_endpoint);
			iScheduledPayment.setHeadersString("Authorization:Bearer "+cc_token);
			iScheduledPayment.setMethod("POST");
			iScheduledPayment.submit();
			
			testVP.assertStringEquals(String.valueOf(iScheduledPayment.getResponseStatusCode()),"201", 
					"Response Code is correct for Domestic Payment Consent");
			
			testVP.assertTrue(!(iScheduledPayment.getResponseNodeStringByPath("Data")).isEmpty(), 
					"Mandatory field Data block");
			
			testVP.assertTrue(iScheduledPayment.getResponseNodeStringByPath("Data.Permission").equals("Create"), 
					"Mandatory field permission is present under Data block and set as Create");
			
			TestLogger.logBlankLine();
			
			testVP.testResultFinalize();

			
	}
	}
