package com.psd2.tests.pisp.POST_InternationalScheduledPaymentConsent;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.psd2.core.TestBase;
import com.psd2.logger.TestListener;
import com.psd2.logger.TestLogger;
import com.psd2.utils.Misc;
import com.psd2.utils.PropertyUtils;

/**
 * Class Description : Verification of Scheme Name and Identification or Name and Postal Address   
 * @author : Rama Arora
 *
 */

@Listeners( { TestListener.class })
@Test(groups={"Regression"})
public class PISP_ISPC_163 extends TestBase{	
	
	@Test
	public void m_PISP_ISPC_163() throws Throwable{	
		
		    TestLogger.logStep("[Step 1] : Creating client credetials....");
			createClientCred.setBaseURL(apiConst.cc_endpoint);
			createClientCred.setScope("payments");
			createClientCred.submit();
			
			testVP.assertStringEquals(String.valueOf(createClientCred.getResponseStatusCode()),"200",
					"Response Code is correct for client credetials");
			cc_token = createClientCred.getAccessToken();
			TestLogger.logVariable("AccessToken : " + cc_token);
			TestLogger.logBlankLine();
			
			TestLogger.logStep("[Step 2] : International Scheduled Payment Consent SetUp....");
			iScheduledPayment.setBaseURL(apiConst.iScheduledPaymentConsent_endpoint);
			iScheduledPayment.setHeadersString("Authorization:Bearer "+cc_token);
			iScheduledPayment.setCrAgentSchemeName("UK.OBIE.BICFI");
			String requestBody=iScheduledPayment.genRequestBody().replace(",\"Identification\": \"BIC\"","");
			requestBody	= requestBody.replace(",\"Name\": \"CreditAgentTest\"","");
			iScheduledPayment.removeCreditorAgentPostalAddress();
			iScheduledPayment.submit(requestBody);
			
			testVP.assertStringEquals(String.valueOf(iScheduledPayment.getResponseStatusCode()),"400", 
					"Response Code is correct for International scheduled Payment Consent URI when CreditorAgent/SchemeName is passed");		
			
			testVP.assertStringEquals(iScheduledPayment.getResponseNodeStringByPath("Errors[0].ErrorCode"), "UK.OBIE.Field.Missing", 
					"Error code for the response is correct i.e. '"+iScheduledPayment.getResponseNodeStringByPath("Errors[0].ErrorCode")+"'");		
			
			testVP.assertTrue(iScheduledPayment.getResponseNodeStringByPath("Errors[0].Message").equals("Incomplete Creditor Agent Provided"), 
					"Message for error code is '"+iScheduledPayment.getResponseNodeStringByPath("Errors[0].Message")+"'");
			
			TestLogger.logBlankLine();
			
			TestLogger.logStep("[Step 3] : International Scheduled Payment Consent SetUp....");
			iScheduledPayment.setBaseURL(apiConst.iScheduledPaymentConsent_endpoint);
			iScheduledPayment.setHeadersString("Authorization:Bearer "+cc_token+",x-idempotency-key:"+PropertyUtils.getProperty("idempotency_key")+"."+Misc.generateString(4));
			requestBody = iScheduledPayment.genRequestBody().replace("\"SchemeName\": \"UK.OBIE.BICFI\",","");
			requestBody = requestBody.replace("\"Identification\": \"BIC\",","");
			requestBody	= requestBody.replace("\"Name\": \"CreditAgentTest\",","");
			iScheduledPayment.submit(requestBody);
			
			testVP.assertStringEquals(String.valueOf(iScheduledPayment.getResponseStatusCode()),"400", 
					"Response Code is correct for International scheduled Payment Consent URI when CreditorAgent/SchemeName is passed");		
			
			testVP.assertStringEquals(iScheduledPayment.getResponseNodeStringByPath("Errors[0].ErrorCode"), "UK.OBIE.Field.Missing", 
					"Error code for the response is correct i.e. '"+iScheduledPayment.getResponseNodeStringByPath("Errors[0].ErrorCode")+"'");		
			
			testVP.assertTrue(iScheduledPayment.getResponseNodeStringByPath("Errors[0].Message").equals("Incomplete Creditor Agent Provided"), 
					"Message for error code is '"+iScheduledPayment.getResponseNodeStringByPath("Errors[0].Message")+"'");
			
			TestLogger.logBlankLine();
			
			testVP.testResultFinalize();
	}
}
