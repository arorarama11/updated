package com.psd2.tests.pisp.GET_DomesticPayments;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.psd2.core.TestBase;
import com.psd2.logger.TestListener;
import com.psd2.logger.TestLogger;
import com.psd2.utils.API_Constant;
import com.psd2.utils.API_E2E_Utility;

/**
 * Class Description :Verification of response for the payments API when the Amount starts with "700" in the POST resquest payload 
 * @author Kiran Dewangan
 *
 */

@Listeners( { TestListener.class })
@Test(groups={"Regression"},dependsOnGroups={"DP"})
public class PISP_GDPS_081 extends TestBase{	
	API_E2E_Utility apiUtility = new API_E2E_Utility();
	@Test
	public void m_PISP_GDPC_080() throws Throwable{	
		
		TestLogger.logStep("[Step 1-1] : Creating client credetials....");
			
		createClientCred.setBaseURL(apiConst.cc_endpoint);
		createClientCred.setScope("payments");
		createClientCred.submit();
			
		testVP.assertStringEquals(String.valueOf(createClientCred.getResponseStatusCode()),"200",
				"Response Code is correct for client credetials");
		cc_token = createClientCred.getAccessToken();
		TestLogger.logVariable("AccessToken : " + cc_token);
		API_Constant.setPisp_CC_AccessToken(cc_token);	
		TestLogger.logBlankLine();
			
		TestLogger.logStep("[Step 1-2] : Domestic Payment Consent SetUp....");
			
		paymentConsent.setBaseURL(apiConst.dpc_endpoint);
		paymentConsent.setHeadersString("Authorization:Bearer "+cc_token);
		paymentConsent.setAmount("700.00");
		paymentConsent.submit();
			
		testVP.assertStringEquals(String.valueOf(paymentConsent.getResponseStatusCode()),"201", "Response Code is correct for Domestic Payment Consent");
		consentId = paymentConsent.getConsentId();
		TestLogger.logVariable("Consent Id : " + consentId);
		TestLogger.logBlankLine();
			
		TestLogger.logStep("[Step 1-3] : Request Object Creation....");
			
		reqObject.setBaseURL(apiConst.ro_endpoint);
		reqObject.setValueField(consentId);
		reqObject.setScopeField("payments");
		reqObject.submit();
			
		testVP.assertStringEquals(String.valueOf(reqObject.getResponseStatusCode()),"200", "Response Code is correct for request object creation");
		outId = reqObject.getOutId();
		TestLogger.logVariable("Request Object Out Id : " + outId);
		TestLogger.logBlankLine();
			
		TestLogger.logStep("[Step 1-4] : Go to URL and authenticate consent");	
		redirecturl = apiConst.pispconsent_URL.replace("#token_RequestGeneration#", outId);
		startDriverInstance();
		authCode = consentOps.authorisePISPConsent(redirecturl,paymentConsent.addDebtorAccount);		
		closeDriverInstance();
		TestLogger.logBlankLine();

		TestLogger.logStep("[Step 1-5] : Get access token");	
		accesstoken.setBaseURL(apiConst.at_endpoint);
		accesstoken.setAuthCode(authCode);
		accesstoken.submit();
			
		testVP.assertStringEquals(String.valueOf(accesstoken.getResponseStatusCode()),"200", 
				"Response Code is correct for get access token request");	
		access_token = accesstoken.getAccessToken();
		TestLogger.logVariable("Access Token : " + access_token);		
		TestLogger.logBlankLine();
			
		TestLogger.logStep("[Step 1-6] : Domestic Payment ");	
		paymentConsent.setBaseURL(apiConst.dps_endpoint);
		paymentConsent.setHeadersString("Authorization:Bearer "+access_token);
		paymentConsent.setConsentId(consentId);
		paymentConsent.submit();
						
		testVP.assertStringEquals(String.valueOf(paymentConsent.getResponseStatusCode()),"201", 
				"Response Code is correct for POST Domestic schedule Payment Submission");
		paymentId=paymentConsent.getPaymentId();
		
		TestLogger.logStep("[Step 1-7] : Get Domestic Schedule Payment ");	
		paymentConsent.setBaseURL(apiConst.dps_endpoint+"/"+paymentId);
		paymentConsent.setHeadersString("Authorization:Bearer "+cc_token);
		paymentConsent.setMethod("GET");
		paymentConsent.submit();
			
		testVP.assertStringEquals(String.valueOf(paymentConsent.getResponseStatusCode()),"500", 
				"Response Code is correct for POST Domestic schedule Payment Submission");
		
		TestLogger.logBlankLine();
		testVP.testResultFinalize();
	}
}